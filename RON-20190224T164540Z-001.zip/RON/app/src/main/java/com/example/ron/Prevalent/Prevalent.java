package com.example.ron.Prevalent;

import com.example.ron.Model.Users;

public class Prevalent
{
    private static Users currentOnlineUser;
}
